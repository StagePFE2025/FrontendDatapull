import React, { useState, useEffect, useRef, useCallback } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { Search, MapPin, X, Plus, Minus} from "./components/Icons";
import Button from "./components/Button";
import RestaurantListItem from "./components/RestaurantListItem";
import RestaurantMapMarker from "./components/RestaurantMapMarker";
import RestaurantDetails from "./components/RestaurantDetailsPopup";
import Badge from "./components/Badge";
import { searchRestaurants } from "./api";
import "./style.css";
import "./components/style2.css";

const MapSmiffer = () => {
  // États
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [city, setCity] = useState("Paris");
  const [category, setCategory] = useState("");
  const [hoveredRestaurant, setHoveredRestaurant] = useState(null);
  const [selectedRestaurant, setSelectedRestaurant] = useState(null);
  const [mapZoom, setMapZoom] = useState(13);
  const [showFilters, setShowFilters] = useState(false);
  const [activeFilters, setActiveFilters] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [favorites, setFavorites] = useState([1, 3]);
  const [allRestaurants, setAllRestaurants] = useState([]); // Pour la liste
  const [restaurants, setRestaurants] = useState([]); // Pour la carte
  const [totalResults, setTotalResults] = useState(0);
  const [currentPage, setCurrentPage] = useState(0);
  const [pageSize, setPageSize] = useState(50);
  const [categoryQuery, setCategoryQuery] = useState("");
  const [error, setError] = useState(null);
  
  // Refs
  const mapRef = useRef(null);
  const mapInstanceRef = useRef(null);

  // Fonction pour récupérer les restaurants
  const fetchRestaurants = async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      const filters = { name: searchQuery, city, query: categoryQuery };
      const result = await searchRestaurants(filters, currentPage, pageSize);
      
      if (result && result.page && Array.isArray(result.page.content)) {
        const normalizedAllRestaurants = result.page.content.map(
          (restaurant) => ({
            ...restaurant,
            // Normaliser les heures pour éviter les erreurs
            hours: Array.isArray(restaurant.hours)
              ? restaurant.hours
              : typeof restaurant.hours === "object" && restaurant.hours.times
              ? restaurant.hours.times
              : restaurant.hours || "Horaires non disponibles",
            // S'assurer que rating et reviews existent
            rating: restaurant.rating || 0,
            reviews: restaurant.reviews || 0,
            // Assurer d'autres propriétés importantes
            address: restaurant.address || "Adresse non disponible",
            featuredImage: restaurant.featuredImage || null
          })
        );

        // Filtrer les restaurants avec des coordonnées valides pour la carte
        const mapRestaurants = normalizedAllRestaurants.filter(
          (restaurant) =>
            typeof restaurant.latitude === "number" &&
            typeof restaurant.longitude === "number" &&
            !isNaN(restaurant.latitude) &&
            !isNaN(restaurant.longitude)
        );

        setAllRestaurants(normalizedAllRestaurants); // Pour la liste
        setRestaurants(mapRestaurants); // Pour la carte
        setTotalResults(result.totalResults || 0);
        
        if (mapRestaurants.length < normalizedAllRestaurants.length) {
          console.warn(
            `${
              normalizedAllRestaurants.length - mapRestaurants.length
            } restaurants filtrés en raison de coordonnées invalides`
          );
        }
      } else {
        console.error("Format de réponse API invalide:", result);
        setError("Format de réponse API invalide. Veuillez réessayer.");
        setAllRestaurants([]);
        setRestaurants([]);
        setTotalResults(0);
      }
      
      setIsLoading(false);
    } catch (error) {
      console.error("Erreur lors de la récupération des restaurants:", error);
      setError("Une erreur est survenue lors du chargement des données. Veuillez réessayer.");
      setIsLoading(false);
      setAllRestaurants([]);
      setRestaurants([]);
      setTotalResults(0);
    }
  };

  // Chargement initial des données
  useEffect(() => {
    fetchRestaurants();
  }, []);

  // Mise à jour lors du changement de page ou de taille de page
  useEffect(() => {
    fetchRestaurants();
  }, [currentPage, pageSize]);

  // Gestionnaires d'événements
  const handleCategoryChange = (e) => {
    setCategoryQuery(e.target.value);
  };

  const clearCategoryField = () => {
    setCategoryQuery("");
  };

  const handleSearch = () => {
    setCurrentPage(0);
    fetchRestaurants();
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter") {
      handleSearch();
    }
  };

  const handlePageChange = (newPage) => {
    setCurrentPage(newPage);
  };

  const handlePageSizeChange = (e) => {
    setPageSize(parseInt(e.target.value));
    setCurrentPage(0);
  };

  const handleCityChange = (e) => {
    setCity(e.target.value);
  };

  const clearCityField = () => {
    setCity("");
  };

  const toggleFilter = (filter) => {
    if (["American", "Italian", "Japanese", "Mexican"].includes(filter)) {
      if (category === filter) {
        setCategory("");
      } else {
        setCategory(filter);
      }
      handleSearch();
    } else {
      setActiveFilters((prev) =>
        prev.includes(filter)
          ? prev.filter((f) => f !== filter)
          : [...prev, filter]
      );
    }
  };

  const toggleFavorite = useCallback((id) => {
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((favId) => favId !== id) : [...prev, id]
    );
  }, []);

  // Gestionnaire pour afficher les détails d'un restaurant
  const handleShowDetails = useCallback((restaurant) => {
    setSelectedRestaurant(restaurant);
  }, []);

  // Gestionnaire pour fermer la vue détaillée
  const handleCloseDetails = useCallback(() => {
    setSelectedRestaurant(null);
  }, []);

  // Gestionnaire pour le survol d'un restaurant dans la liste
  const handleRestaurantHover = useCallback((restaurant) => {
    setHoveredRestaurant(restaurant);
  }, []);

  // Gestionnaire pour la fin du survol
  const handleRestaurantLeave = useCallback(() => {
    setHoveredRestaurant(null);
  }, []);

  const handleToggleDarkMode = () => {
    setIsDarkMode((prev) => !prev);
  };

  // Calculer le nombre total de pages
  const totalPages = Math.ceil(totalResults / pageSize);

  // Initialisation et nettoyage de la carte
  useEffect(() => {
    if (!mapInstanceRef.current && mapRef.current) {
      try {
        // Initialiser la carte Leaflet
        mapInstanceRef.current = L.map(mapRef.current, {
          center: [48.8566, 2.3522], // Paris par défaut
          zoom: mapZoom,
          zoomControl: false,
        });

        // Ajouter la couche de tuiles OpenStreetMap
        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          attribution:
            '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        }).addTo(mapInstanceRef.current);
      } catch (error) {
        console.error("Erreur lors de l'initialisation de la carte:", error);
      }
    }

    // Mettre à jour le zoom si la carte est déjà initialisée
    if (mapInstanceRef.current) {
      mapInstanceRef.current.setZoom(mapZoom);
    }

    // Nettoyer la carte lors du démontage du composant
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, [mapZoom]);

  // Ajuster la vue de la carte en fonction des restaurants
  useEffect(() => {
    if (restaurants.length > 0 && mapInstanceRef.current) {
      try {
        // Extraire les coordonnées valides pour définir les limites de la carte
        const validCoordinates = restaurants
          .filter(
            (r) =>
              typeof r.latitude === "number" &&
              typeof r.longitude === "number" &&
              !isNaN(r.latitude) &&
              !isNaN(r.longitude)
          )
          .map((r) => [r.latitude, r.longitude]);
          
        if (validCoordinates.length > 0) {
          // Créer des limites pour inclure tous les restaurants
          const bounds = L.latLngBounds(validCoordinates);
          mapInstanceRef.current.fitBounds(bounds, { padding: [50, 50] });
        } else {
          // Fallback à Paris si aucune coordonnée valide
          mapInstanceRef.current.setView([48.8566, 2.3522], 13);
        }
      } catch (error) {
        console.error("Erreur lors de l'ajustement de la vue de la carte:", error);
      }
    }
  }, [restaurants]);

  // Zoomer sur un restaurant survolé
  useEffect(() => {
    if (hoveredRestaurant && mapInstanceRef.current) {
      try {
        const { latitude, longitude } = hoveredRestaurant;
        
        if (
          typeof latitude === "number" &&
          typeof longitude === "number" &&
          !isNaN(latitude) &&
          !isNaN(longitude)
        ) {
          // Centrer la carte sur le restaurant survolé sans changer le niveau de zoom
          mapInstanceRef.current.setView([latitude, longitude], mapInstanceRef.current.getZoom());
        }
      } catch (error) {
        console.error("Erreur lors du centrage sur le restaurant survolé:", error);
      }
    }
  }, [hoveredRestaurant]);

  // Contrôle du zoom
  const handleZoomIn = () => setMapZoom((prev) => Math.min(prev + 1, 18));
  const handleZoomOut = () => setMapZoom((prev) => Math.max(prev - 1, 10));

  return (
    <div className={`map-container ${isDarkMode ? "dark" : ""}`}>
      {/* Bouton pour basculer le mode sombre */}
      <button
        className={`theme-toggle-button ${isDarkMode ? "dark" : ""}`}
        onClick={handleToggleDarkMode}
        style={{
          position: "absolute",
          top: "1rem",
          right: "1rem",
          zIndex: 1000,
          backgroundColor: isDarkMode ? "#374151" : "white",
          color: isDarkMode ? "white" : "#374151",
          border: "none",
          borderRadius: "0.375rem",
          padding: "0.5rem",
          cursor: "pointer",
          boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
        }}
      >

      </button>

      {/* Barre latérale */}
      <div className={`sidebar ${isDarkMode ? "dark" : ""}`}>
        <div className={`search-container ${isDarkMode ? "dark" : ""}`}>
          <div className="search-input-container">
            <Search
              size={12}
              className={`search-icon ${isDarkMode ? "dark" : ""}`}
            />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Rechercher par nom "
              className={`search-input ${isDarkMode ? "dark" : ""}`}
            />
            <Button className="search-button" onClick={handleSearch} size="sm">
              Rechercher
            </Button>
          </div>
        </div>

        <div className={`location-container ${isDarkMode ? "dark" : ""}`}>
          <div className={`location-input ${isDarkMode ? "dark" : ""}`}>
            <div className="location-info">
              <Search
                size={16}
                className={`category-icon ${isDarkMode ? "dark" : ""}`}
              />
              <input
                type="text"
                value={categoryQuery}
                onChange={handleCategoryChange}
                onKeyPress={handleKeyPress}
                placeholder="Catégorie (ex: restaurant, café, hotel...)"
                className={`location-text-input ${isDarkMode ? "dark" : ""}`}
              />
            </div>
            <button
              onClick={clearCategoryField}
              className={`clear-button ${isDarkMode ? "dark" : ""}`}
            >
              <X
                size={16}
                className={`clear-icon ${isDarkMode ? "dark" : ""}`}
              />
            </button>
          </div>
          <div className={`location-input ${isDarkMode ? "dark" : ""}`} style={{ marginTop: "10px" }}>
            <div className="location-info">
              <MapPin
                size={16}
                className={`location-icon ${isDarkMode ? "dark" : ""}`}
              />
              <input
                type="text"
                value={city}
                onChange={handleCityChange}
                onKeyPress={handleKeyPress}
                placeholder="Ville"
                className={`location-text-input ${isDarkMode ? "dark" : ""}`}
              />
            </div>
            <button
              onClick={clearCityField}
              className={`clear-button ${isDarkMode ? "dark" : ""}`}
            >
              <X
                size={16}
                className={`clear-icon ${isDarkMode ? "dark" : ""}`}
              />
            </button>
          </div>
        </div>

        <div className={`filters-container ${isDarkMode ? "dark" : ""}`}>
          <button
            className={`filters-toggle ${isDarkMode ? "dark" : ""}`}
            onClick={() => setShowFilters(!showFilters)}
          >
            <span>Filtres</span>
            <span className={`toggle-icon ${showFilters ? "open" : ""}`}>
              ▼
            </span>
          </button>
          {showFilters && (
            <div className="filters-content">
              <div className="filter-section">
                <p className="filter-label">Cuisine</p>
                <div className="filter-options">
                  {["American", "Italian", "Japanese", "Mexican"].map(
                    (cuisine) => (
                      <Badge
                        key={cuisine}
                        variant={category === cuisine ? "default" : "outline"}
                        className={`filter-badge ${
                          category === cuisine ? "active" : ""
                        } ${isDarkMode ? "dark" : ""}`}
                        onClick={() => toggleFilter(cuisine)}
                      >
                        {cuisine}
                      </Badge>
                    )
                  )}
                </div>
              </div>
              <div className="filter-section">
                <p className="filter-label">Prix</p>
                <div className="filter-options">
                  {["$", "$$", "$$$", "$$$$"].map((price) => (
                    <Badge
                      key={price}
                      variant={
                        activeFilters.includes(price) ? "default" : "outline"
                      }
                      className={`filter-badge ${
                        activeFilters.includes(price) ? "active" : ""
                      } ${isDarkMode ? "dark" : ""}`}
                      onClick={() => toggleFilter(price)}
                    >
                      {price}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        <div className={`results-count ${isDarkMode ? "dark" : ""}`}>
          <span className="count-text">
            {isLoading ? "Chargement..." : `${totalResults} résultats trouvés`}
          </span>
        </div>

        {/* Message d'erreur */}
        {error && (
          <div className={`error-message ${isDarkMode ? "dark" : ""}`}>
            {error}
          </div>
        )}

        {/* Liste des restaurants */}
        <div className="restaurant-list">
          {isLoading ? (
            // Squelettes de chargement
            Array(4)
              .fill(0)
              .map((_, index) => (
                <div
                  key={index}
                  className={`skeleton-item ${isDarkMode ? "dark" : ""}`}
                >
                  <div className="skeleton-content">
                    <div className="skeleton-info">
                      <div className="skeleton-line-large"></div>
                      <div className="skeleton-line-small"></div>
                      <div className="skeleton-line-medium"></div>
                      <div className="skeleton-line-small"></div>
                    </div>
                    <div className="skeleton-image"></div>
                  </div>
                </div>
              ))
          ) : allRestaurants.length === 0 ? (
            <div className="no-results">Aucun résultat trouvé.</div>
          ) : (
            // Liste des restaurants
            allRestaurants.map((restaurant) => {
              const isHovered = hoveredRestaurant?.id === restaurant.id;
              return (
                <RestaurantListItem
                  key={restaurant.id}
                  restaurant={restaurant}
                  isHovered={isHovered}
                  isFavorite={favorites.includes(restaurant.id)}
                  onHover={handleRestaurantHover}
                  onLeave={handleRestaurantLeave}
                  onShowDetails={handleShowDetails}
                  onFavoriteToggle={() => toggleFavorite(restaurant.id)}
                  isDarkMode={isDarkMode}
                />
              );
            })
          )}
        </div>

        {/* Pagination */}
        <div className={`pagination-container ${isDarkMode ? "dark" : ""}`}>
          <div className="pagination-controls">
            <Button
              onClick={() => handlePageChange(Math.max(0, currentPage - 1))}
              disabled={currentPage === 0}
              size="sm"
              variant={isDarkMode ? "outline" : "secondary"}
            >
              Précédent
            </Button>
            <div className="pagination-info">
              Page {currentPage + 1} sur {totalPages || 1}
            </div>
            <Button
              onClick={() =>
                handlePageChange(Math.min(totalPages - 1, currentPage + 1))
              }
              disabled={currentPage >= totalPages - 1}
              size="sm"
              variant={isDarkMode ? "outline" : "secondary"}
            >
              Suivant
            </Button>
          </div>
          <div className="page-size-selector">
            <span>Résultats par page:</span>
            <select
              value={pageSize}
              onChange={handlePageSizeChange}
              className={isDarkMode ? "dark" : ""}
            >
              <option value="50">50</option>
              <option value="100">100</option>
              <option value="500">500</option>
            </select>
          </div>
        </div>
      </div>

      {/* Vue de la carte */}
      <div className="map-view">
        <div className="map-content">
          <div
            ref={mapRef}
            className={`map-image-container ${isDarkMode ? "dark" : ""}`}
            style={{ height: "100%", width: "100%" }}
          />
          
          {/* Contrôles de zoom */}
          <div className={`map-controls ${isDarkMode ? "dark" : ""}`}>
            <button
              className={`zoom-button ${isDarkMode ? "dark" : ""}`}
              onClick={handleZoomIn}
            >
              <Plus size={18} />
            </button>
            <button
              className={`zoom-button ${isDarkMode ? "dark" : ""}`}
              onClick={handleZoomOut}
            >
              <Minus size={18} />
            </button>
          </div>
          
          {/* Marqueurs sur la carte */}
          {restaurants.map((restaurant) => (
            <RestaurantMapMarker
              key={restaurant.id}
              restaurant={restaurant}
              isHovered={hoveredRestaurant?.id === restaurant.id}
              isFavorite={favorites.includes(restaurant.id)}
              //onHover={() => handleRestaurantHover(restaurant)}
              onLeave={handleRestaurantLeave}
              onShowDetails={handleShowDetails}
              onFavoriteToggle={() => toggleFavorite(restaurant.id)}
              isDarkMode={isDarkMode}
              map={mapInstanceRef.current}
            />
          ))}
        </div>
      </div>

      {/* Détails du restaurant sélectionné */}
      {selectedRestaurant && (
        <RestaurantDetails
          restaurant={selectedRestaurant}
          isFavorite={favorites.includes(selectedRestaurant.id)}
          onClose={handleCloseDetails}
          onFavoriteToggle={() => toggleFavorite(selectedRestaurant.id)}
          isDarkMode={isDarkMode}
        />
      )}
    </div>
  );
};

export default MapSmiffer;