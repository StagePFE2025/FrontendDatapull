import React, { useEffect } from "react";
import { X, Heart, MapPin, Clock, Phone, Globe } from "./Icons";

const RestaurantDetails = ({
  restaurant,
  isFavorite,
  onClose,
  onFavoriteToggle,
  isDarkMode,
}) => {
  if (!restaurant) return null;
  
  // Empêcher le défilement de la page quand le popup est ouvert
  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = "auto";
    };
  }, []);

  // Fermer avec la touche Escape
  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === "Escape") onClose();
    };
    
    window.addEventListener("keydown", handleEscape);
    return () => {
      window.removeEventListener("keydown", handleEscape);
    };
  }, [onClose]);

  return (
    <div className={`popup-overlay ${isDarkMode ? "dark" : ""}`}>
      <div className="restaurant-details">
        <div className="details-header">
          <img
            src={restaurant.featuredImage || "https://fakeimg.pl/600x400?text=Image"}
            alt={restaurant.name}
            className="details-image"
            onError={(e) => (e.target.src = "https://fakeimg.pl/600x400?text=Image")}
          />
          <div className="image-overlay"></div>
          
          <button
            className="details-close-button"
            onClick={onClose}
          >
            <X size={20} />
          </button>
          
          <button
            className="details-favorite-button"
            onClick={(e) => {
              e.stopPropagation();
              onFavoriteToggle();
            }}
          >
            <Heart size={20} fill={isFavorite} />
          </button>
          
          <div className="details-header-info">
            <h2 className="details-title">{restaurant.name}</h2>
            <div className="details-rating">
              <span className="rating-text">{restaurant.rating || 0} ★</span>
              <span className="rating-text">({restaurant.reviews || 0} avis)</span>
            </div>
          </div>
        </div>
        
        <div className="details-content">
          <div className="details-info-section">
            {restaurant.address && (
              <div className="details-address">
                <MapPin size={16} className={`details-info-icon ${isDarkMode ? "dark" : ""}`} />
                <p className={`details-info-text ${isDarkMode ? "dark" : ""}`}>{restaurant.address}</p>
              </div>
            )}
            
            {restaurant.phone && (
              <div className="details-phone">
                <Phone size={16} className={`details-info-icon ${isDarkMode ? "dark" : ""}`} />
                <p className={`details-info-text ${isDarkMode ? "dark" : ""}`}>{restaurant.phone}</p>
              </div>
            )}
            
            {restaurant.hours && (
              <div className="details-hours">
                <Clock size={16} className={`details-info-icon ${isDarkMode ? "dark" : ""}`} />
                <p className={`details-info-text ${isDarkMode ? "dark" : ""}`}>
                  {Array.isArray(restaurant.hours) 
                    ? restaurant.hours.join(", ") 
                    : typeof restaurant.hours === "object" && restaurant.hours.times
                      ? restaurant.hours.times
                      : restaurant.hours}
                </p>
              </div>
            )}
            
            {restaurant.website && (
              <div className="details-website">
                <Globe size={16} className={`details-info-icon ${isDarkMode ? "dark" : ""}`} />
                <p className={`details-info-text ${isDarkMode ? "dark" : ""}`}>
                  <a 
                    href={restaurant.website} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="text-blue-500"
                  >
                    {restaurant.website}
                  </a>
                </p>
              </div>
            )}
          </div>
          
          <div className="details-actions">
            <button 
              className={`details-button close-button ${isDarkMode ? "dark" : ""}`}
              onClick={onClose}
            >
              Fermer
            </button>
            
            {restaurant.website && (
              <a 
                href={restaurant.website} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="details-button website-button"
              >
                Visiter le site
              </a>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RestaurantDetails;